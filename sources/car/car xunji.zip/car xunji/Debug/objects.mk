################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -Wl,-ldevice.cmd.genlibs -Wl,-llibc.a -Wl,-l"C:/ti/ccs2051/mspm0_sdk_2_10_00_04/source/ti/driverlib/lib/ticlang/m0p/mspm0g1x0x_g3x0x/driverlib.a"

