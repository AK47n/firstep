#include "ti/devices/msp/m0p/mspm0g350x.h"
#include "ti_msp_dl_config.h"
#include "Delay.h"
#include "control.h"
#include "JY61P.h"

int main(void)
{
	SYSCFG_DL_init();

	DL_Timer_startCounter(PWM_0_INST);

	// 使能TB6612
	DL_GPIO_setPins(GPIO_STBY_PORT, GPIO_STBY_PIN_STBY_PIN);
	Delay_ms(100);

	// 初始停止
	AIN10; AIN20;
	BIN10; BIN20;
	DL_Timer_setCaptureCompareValue(PWM_0_INST, 2500, DL_TIMER_CC_0_INDEX);
	DL_Timer_setCaptureCompareValue(PWM_0_INST, 2500, DL_TIMER_CC_1_INDEX);

	int mode    = 0;  // 0=AB, 1=ABCDA, 2=ACBDA, 3=ACBDAx4
	int running = 0;

	while (1) {
		/*** S2：切换模式（消抖：连续3次读到低才确认） ***/
		if (!DL_GPIO_readPins(GPIO_Key_PORT, GPIO_Key_PIN_S2_PIN)) {
			Delay_ms(10);
			if (!DL_GPIO_readPins(GPIO_Key_PORT, GPIO_Key_PIN_S2_PIN)) {
				Delay_ms(10);
				if (!DL_GPIO_readPins(GPIO_Key_PORT, GPIO_Key_PIN_S2_PIN)) {
					mode = (mode + 1) % 4;
					// 等待按键释放
					while (!DL_GPIO_readPins(GPIO_Key_PORT, GPIO_Key_PIN_S2_PIN));
					Delay_ms(30);
				}
			}
		}

		/*** S1：启动 / 停止 ***/
		if (!DL_GPIO_readPins(GPIO_Key_PORT, GPIO_Key_PIN_S1_PIN)) {
			Delay_ms(10);
			if (!DL_GPIO_readPins(GPIO_Key_PORT, GPIO_Key_PIN_S1_PIN)) {
				Delay_ms(10);
				if (!DL_GPIO_readPins(GPIO_Key_PORT, GPIO_Key_PIN_S1_PIN)) {
					if (running) {
						// 停止
						running = 0;
						AIN10; AIN20;
						BIN10; BIN20;
						DL_Timer_setCaptureCompareValue(PWM_0_INST, 2500, DL_TIMER_CC_0_INDEX);
						DL_Timer_setCaptureCompareValue(PWM_0_INST, 2500, DL_TIMER_CC_1_INDEX);
					} else {
						// 启动：归零陀螺仪 → 重置状态 → 跑
						Serial_JY61P_Zero_Yaw();
						Delay_ms(200);
						AB_State_Reset();
						ABCD_State_Reset();
						running = 1;
					}
					// 等待按键释放
					while (!DL_GPIO_readPins(GPIO_Key_PORT, GPIO_Key_PIN_S1_PIN));
					Delay_ms(30);
				}
			}
		}

		/*** 运行对应模式 ***/
		if (running) {
			switch (mode) {
			case 0: Control_AB();       break;
			case 1: Control_ABCDA();    break;
			case 2: Control_ACBDA();    break;
			case 3: Control_ACBDAx4();  break;
			}
		}

		Delay_ms(50);
	}
}
