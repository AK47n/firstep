#include "ti_msp_dl_config.h"
#include "Delay.h"

/******************** JY61P 陀螺仪数据 ********************/
uint8_t RollL, RollH, PitchL, PitchH, YawL, YawH, VL, VH, SUM;
float   Pitch, Roll, Yaw;

/******************** UART接收状态机 ********************/
#define WAIT_HEADER1 0
#define WAIT_HEADER2 1
#define RECEIVE_DATA 2

uint8_t RxState     = WAIT_HEADER1;
uint8_t receivedData[9];
uint8_t dataIndex   = 0;

/******************** JY61P 发送单字节 ********************/
static void JY61P_SendByte(uint8_t data)
{
	DL_UART_Main_transmitDataBlocking(UART_JY61P_INST, data);
}

/******************** JY61P 发送命令帧 ********************/
static void JY61P_SendCmd(uint8_t cmd)
{
	JY61P_SendByte(0xFF);
	JY61P_SendByte(0xAA);
	JY61P_SendByte(cmd);
}

/******************** JY61P 偏航角归零 ********************/
void Serial_JY61P_Zero_Yaw(void)
{
	/*** 方法1: 发送 Heading Reset 命令 (FF AA 52) ***/
	JY61P_SendCmd(0x52);
	Delay_ms(50);

	/*** 方法2: 寄存器解锁+写CALSW偏航重置位+保存 ***/
	// Unlock: FF AA 69 88 B5
	JY61P_SendByte(0xFF);
	JY61P_SendByte(0xAA);
	JY61P_SendByte(0x69);
	JY61P_SendByte(0x88);
	JY61P_SendByte(0xB5);
	Delay_ms(50);

	// 写 CALSW 寄存器(0x01): bit2=1 → 偏航角重置
	// FF AA 01 04 00
	JY61P_SendByte(0xFF);
	JY61P_SendByte(0xAA);
	JY61P_SendByte(0x01);
	JY61P_SendByte(0x04);
	JY61P_SendByte(0x00);
	Delay_ms(50);

	// 保存: FF AA 00 00 00
	JY61P_SendByte(0xFF);
	JY61P_SendByte(0xAA);
	JY61P_SendByte(0x00);
	JY61P_SendByte(0x00);
	JY61P_SendByte(0x00);
	Delay_ms(100);
}

/******************** JY61P UART中断接收 ********************/
void UART_JY61P_INST_IRQHandler(void)
{
	uint8_t uartdata = DL_UART_Main_receiveData(UART_JY61P_INST);

	switch (RxState) {
	case WAIT_HEADER1:
		if (uartdata == 0x55) {
			RxState = WAIT_HEADER2;
		}
		break;

	case WAIT_HEADER2:
		if (uartdata == 0x53) {
			// 0x55 0x53 = 角度数据包
			RxState   = RECEIVE_DATA;
			dataIndex = 0;
		} else if (uartdata == 0x52) {
			// 0x55 0x52 = 四元数/磁场数据包（忽略）
			// 跳过这个数据包，重置状态
			RxState = WAIT_HEADER1;
		} else if (uartdata == 0x51) {
			// 0x55 0x51 = 加速度数据包（忽略）
			RxState = WAIT_HEADER1;
		} else if (uartdata == 0x54) {
			// 0x55 0x54 = 角速度数据包（忽略）
			RxState = WAIT_HEADER1;
		} else {
			RxState = WAIT_HEADER1;
		}
		break;

	case RECEIVE_DATA:
		receivedData[dataIndex++] = uartdata;
		if (dataIndex == 9) {
			// 数据接收完毕
			RollL  = receivedData[0];
			RollH  = receivedData[1];
			PitchL = receivedData[2];
			PitchH = receivedData[3];
			YawL   = receivedData[4];
			YawH   = receivedData[5];
			VL     = receivedData[6];
			VH     = receivedData[7];
			SUM    = receivedData[8];

			// 校验和
			uint8_t calcSum = 0x55 + 0x53
			                + RollH + RollL
			                + PitchH + PitchL
			                + YawH + YawL
			                + VH + VL;

			if (calcSum == SUM) {
				// 解析角度: Value = ((H<<8)|L) / 32768 * 180
				int16_t raw;

				raw = (int16_t)(((uint16_t)RollH << 8) | RollL);
				Roll = (float)raw / 32768.0f * 180.0f;

				raw = (int16_t)(((uint16_t)PitchH << 8) | PitchL);
				Pitch = (float)raw / 32768.0f * 180.0f;

				raw = (int16_t)(((uint16_t)YawH << 8) | YawL);
				Yaw = (float)raw / 32768.0f * 180.0f;
			}
			RxState = WAIT_HEADER1;
		}
		break;
	}
}
