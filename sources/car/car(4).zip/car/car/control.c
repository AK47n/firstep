#include "control.h"

/******************** 灰度传感器 ********************/
#define P1	DL_GPIO_readPins(GPIO_Gray_PIN_Gray_1_PORT, GPIO_Gray_PIN_Gray_1_PIN)
#define P2	DL_GPIO_readPins(GPIO_Gray_PIN_Gray_2_PORT, GPIO_Gray_PIN_Gray_2_PIN)
#define P3	DL_GPIO_readPins(GPIO_Gray_PIN_Gray_3_PORT, GPIO_Gray_PIN_Gray_3_PIN)
#define P4	DL_GPIO_readPins(GPIO_Gray_PIN_Gray_4_PORT, GPIO_Gray_PIN_Gray_4_PIN)
#define P5	DL_GPIO_readPins(GPIO_Gray_PIN_Gray_5_PORT, GPIO_Gray_PIN_Gray_5_PIN)
#define P6	DL_GPIO_readPins(GPIO_Gray_PIN_Gray_6_PORT, GPIO_Gray_PIN_Gray_6_PIN)
#define P7	DL_GPIO_readPins(GPIO_Gray_PIN_Gray_7_PORT, GPIO_Gray_PIN_Gray_7_PIN)
#define P8	DL_GPIO_readPins(GPIO_Gray_PIN_Gray_8_PORT, GPIO_Gray_PIN_Gray_8_PIN)

/******************** 外部变量 ********************/
volatile uint32_t gpioA, gpioB;
volatile int32_t gEncoderCount_left  = 0, gEncoderVal_left  = 0;
volatile int32_t gEncoderCount_right = 0, gEncoderVal_right = 0;
extern float Yaw;

/******************** 可调参数 ********************/
#define LIMIT             200
#define ENC_FACTOR_LEFT   3
#define ENC_FACTOR_RIGHT  3

#define KP_SPEED   0.9f
#define KI_SPEED   0.05f
#define KD_SPEED   0.0f

#define ENC_100CM  800

// 陀螺仪直行修正参数
#define GYRO_POLARITY  -1            // -1=反转修正方向（如仍偏右则改回1）
#define GYRO_KP       45.0f          // 加大P
#define GYRO_KI        3.0f          // 加大I
#define GYRO_KD        1.0f          // 降低D
#define GYRO_INTEGRAL_MAX  40.0f     // 积分限幅

// 转弯参数
#define TURN_KP    1.5f
#define TURN_KD    0.6f
#define TURN_DONE  3.0f

#define ARC_GUARD      15

// 赛道角度：矩形/正方形每个弧线转弯90度
#define TRACK_TURN_ANGLE  90.0f

/******************** 全局状态 ********************/
AB_State  g_ab_state  = AB_START_DELAY;
Car_State g_car_state = CAR_FOLLOW_LINE;

float g_heading_ref  = 0.0f;
float g_last_yaw     = 0.0f;
float g_straight_heading = 0.0f;
float g_initial_heading = 0.0f;
float g_turn_target  = 0.0f;
float g_gyro_integral = 0.0f;

int32_t g_enc_dist    = 0;
int32_t g_enc_target  = 0;

int g_seg_count  = 0;
int g_seg_total  = 4;
int g_stable_cnt = 0;
int g_arc_guard  = 0;
int g_gyro_first = 1;
int g_xunji_last = 0;

float g_speed_straight = 25.0f;
float g_speed_arc      = 7.0f;
#define DECEL_ZONE      0.70f

/******************** AB模式：A->B 直线盲走 ********************/

void AB_State_Reset(void)
{
	g_ab_state      = AB_START_DELAY;
	g_enc_dist      = 0;
	g_enc_target    = 0;
	g_gyro_first    = 1;
	g_gyro_integral = 0.0f;
}

void Control_AB(void)
{
	float targetA, targetB, currentA, currentB;
	int   motorL, motorR;
	float bias = 0;

	uint8_t any_black = (!P1 || !P2 || !P3 || !P4 || !P5 || !P6 || !P7 || !P8);

	switch (g_ab_state) {
	case AB_START_DELAY:
		g_heading_ref = Yaw;
		g_ab_state    = AB_RUNNING;
		bias = gyro_straight_correction();
		break;

	case AB_RUNNING:
		bias = gyro_straight_correction();
		if (any_black) {
			g_ab_state = AB_STOPPED;
		}
		break;

	case AB_STOPPED:
		Set_Pwm(0, 0);
		return;

	default:
		g_ab_state = AB_START_DELAY;
		break;
	}

	targetA  = g_speed_straight - bias;
	targetB  = g_speed_straight + bias;
	currentA = (float)gEncoderVal_left  / ENC_FACTOR_LEFT;
	currentB = (float)gEncoderVal_right / ENC_FACTOR_RIGHT;
	motorL   = (int)PWM_Limit(PID_A(currentA, targetA), LIMIT, -LIMIT);
	motorR   = (int)PWM_Limit(PID_B(currentB, targetB), LIMIT, -LIMIT);

	if (g_ab_state == AB_STOPPED) Set_Pwm(0, 0);
	else                           Set_Pwm(motorL, motorR);
}

/******************** ABCD模式状态重置 ********************/
void ABCD_State_Reset(void)
{
	g_car_state        = CAR_STRAIGHT;
	g_heading_ref      = Yaw;
	g_initial_heading  = Yaw;
	g_straight_heading = Yaw;
	g_seg_count        = 0;
	g_enc_dist         = 0;
	g_enc_target       = ENC_100CM;
	g_stable_cnt       = 0;
	g_arc_guard        = 0;
	g_gyro_first       = 1;
	g_xunji_last       = 0;
	g_gyro_integral    = 0.0f;
}

/******************** ABCD模式：A->B(直)->C(弧)->D(直)->A(弧) ********************/
void Control_ABCDA(void)
{
	float targetA, targetB, currentA, currentB;
	int   motorL, motorR;
	float bias = 0;

	uint8_t any_black = (!P1 || !P2 || !P3 || !P4 || !P5 || !P6 || !P7 || !P8);
	int white_cnt = (P1?1:0)+(P2?1:0)+(P3?1:0)+(P4?1:0)+(P5?1:0)+(P6?1:0)+(P7?1:0)+(P8?1:0);

	switch (g_car_state) {

	/*** 循线模式：弧线黑线跟随 ***/
	case CAR_FOLLOW_LINE:
		bias = (float)xunji();
		if (g_arc_guard > 0) {
			g_arc_guard--;
		} else if (white_cnt >= 6) {
			g_stable_cnt++;
			if (g_stable_cnt > 5) {
				g_stable_cnt = 0;
				g_seg_count++;
				if (g_seg_count >= g_seg_total) {
					g_car_state = CAR_FINISHED;
				} else {
					// 计算下一段直行的参考航向（每段弧线转弯TRACK_TURN_ANGLE度）
					g_heading_ref = g_initial_heading + (g_seg_count / 2) * TRACK_TURN_ANGLE;
					if (g_heading_ref >  180.0f) g_heading_ref -= 360.0f;
					if (g_heading_ref < -180.0f) g_heading_ref += 360.0f;
					g_car_state     = CAR_STRAIGHT;
					g_enc_dist      = 0;
					g_enc_target    = ENC_100CM;
					g_gyro_first    = 1;
					g_gyro_integral = 0.0f;
					PID_Reset();
				}
			}
		} else {
			g_stable_cnt = 0;
		}
		break;

	/*** 直线盲走模式：陀螺仪锁航向 ***/
	case CAR_STRAIGHT:
			{
				if (any_black) {
					bias = (float)xunji();
					g_stable_cnt++;
					if (g_stable_cnt > 2) {
						g_stable_cnt = 0;
						g_seg_count++;
						if (g_seg_count >= g_seg_total) {
							g_car_state = CAR_FINISHED;
						} else {
							g_car_state     = CAR_FOLLOW_LINE;
							g_heading_ref   = Yaw;
							g_arc_guard     = ARC_GUARD;
							g_xunji_last    = 0;
							g_gyro_integral = 0.0f;
						}
						PID_Reset();
					}
				} else {
					bias = gyro_straight_correction();
					g_stable_cnt = 0;
				}
			}
			break;

	/*** 停止 ***/
	case CAR_FINISHED:
		Set_Pwm(0, 0);
		return;

	default:
		g_car_state = CAR_FOLLOW_LINE;
		break;
	}

	if (g_car_state == CAR_STRAIGHT) {
		float progress = (float)g_enc_dist / (float)g_enc_target;
		if (progress < DECEL_ZONE) {
			targetA = g_speed_straight;
		} else {
			float ratio = (progress - DECEL_ZONE) / (1.0f - DECEL_ZONE);
			targetA = g_speed_straight + (g_speed_arc - g_speed_straight) * ratio;
		}
	} else {
		targetA = g_speed_arc;
	}
	targetB = targetA;

	targetA -= bias;
	targetB += bias;
	currentA = (float)gEncoderVal_left  / ENC_FACTOR_LEFT;
	currentB = (float)gEncoderVal_right / ENC_FACTOR_RIGHT;
	motorL   = (int)PWM_Limit(PID_A(currentA, targetA), LIMIT, -LIMIT);
	motorR   = (int)PWM_Limit(PID_B(currentB, targetB), LIMIT, -LIMIT);

	if (g_car_state == CAR_FINISHED || g_ab_state == AB_STOPPED)
		Set_Pwm(0, 0);
	else
		Set_Pwm(motorL, motorR);
}

/******************** ACBDA模式 ********************/
void Control_ACBDA(void)
{
	Control_ABCDA();
}

/******************** ACBDAx4模式 ********************/
void Control_ACBDAx4(void)
{
	Control_ABCDA();
}

/******************** 陀螺仪直行修正（带积分项消除稳态误差） ********************/
float gyro_straight_correction(void)
{
	if (g_gyro_first) {
		g_last_yaw      = Yaw;
		g_gyro_first    = 0;
		g_gyro_integral = 0.0f;
		return 0.0f;
	}
	float error = Yaw - g_heading_ref;
	if (error >  180.0f) error -= 360.0f;
	if (error < -180.0f) error += 360.0f;

	// 积分项（加大累积速度）
	g_gyro_integral += error * 0.1f;
	if (g_gyro_integral >  GYRO_INTEGRAL_MAX) g_gyro_integral =  GYRO_INTEGRAL_MAX;
	if (g_gyro_integral < -GYRO_INTEGRAL_MAX) g_gyro_integral = -GYRO_INTEGRAL_MAX;

	float d_yaw      = Yaw - g_last_yaw;
	float correction = (error * GYRO_KP + g_gyro_integral * GYRO_KI + d_yaw * GYRO_KD) * GYRO_POLARITY;
	g_last_yaw = Yaw;

	if (correction >  70.0f) correction =  70.0f;
	if (correction < -70.0f) correction = -70.0f;
	return correction;
}

/******************** 陀螺仪转弯 ********************/
void GYRO_Turn_Init(TurnDir dir)
{
	g_stable_cnt = 0;

	switch (dir) {
	case TURN_LEFT_90:  g_turn_target = Yaw - 90.0f; break;
	case TURN_RIGHT_90: g_turn_target = Yaw + 90.0f; break;
	case TURN_180:      g_turn_target = Yaw + 180.0f; break;
	default:            g_turn_target = Yaw; break;
	}
	if (g_turn_target >  180.0f) g_turn_target -= 360.0f;
	if (g_turn_target < -180.0f) g_turn_target += 360.0f;

	PID_Reset();
}

int GYRO_Turn_Process(void)
{
	float error = g_turn_target - Yaw;
	if (error >  180.0f) error -= 360.0f;
	if (error < -180.0f) error += 360.0f;

	float d_yaw      = Yaw - g_last_yaw;
	float correction = (error * TURN_KP - d_yaw * TURN_KD) * GYRO_POLARITY;
	g_last_yaw = Yaw;

	if (correction >  100.0f) correction =  100.0f;
	if (correction < -100.0f) correction = -100.0f;

	if (myabsf(error) < TURN_DONE) {
		g_stable_cnt++;
		if (g_stable_cnt > 5) {
			g_stable_cnt    = 0;
			g_heading_ref   = Yaw;
			g_enc_dist      = 0;
			g_enc_target    = ENC_100CM;
			g_car_state     = CAR_STRAIGHT;
			g_gyro_integral = 0.0f;
			PID_Reset();
			return 0;
		}
	} else {
		g_stable_cnt = 0;
	}
	return (int)correction;
}

/******************** 循线：弧线黑线跟随 ********************/
int xunji(void)
{
	int ret;
	if (!P4 && !P5) ret = 0;
	else if (!P4)   ret =   8;
	else if (!P5)   ret =  -8;
	else if (!P3)   ret =  12;
	else if (!P6)   ret = -12;
	else if (!P2)   ret =  18;
	else if (!P7)   ret = -18;
	else if (!P1)   ret =  28;
	else if (!P8)   ret = -28;
	else ret = g_xunji_last;

	if (ret != 0) g_xunji_last = ret;
	return ret;
}

int xunji_left(void)
{
	if (!P1 && !P2) return  30;
	if (!P1)        return  20;
	if (!P2)        return  14;
	if (!P3)        return   8;
	if (!P4)        return   4;
	return (int)gyro_straight_correction();
}

int xunji_right(void)
{
	if (!P8 && !P7) return -30;
	if (!P8)        return -20;
	if (!P7)        return -14;
	if (!P6)        return  -8;
	if (!P5)        return  -4;
	return (int)gyro_straight_correction();
}

/******************** 速度PID ********************/
static float PID_A_Bias, PID_A_Last, PID_A_Last2, PID_A_Pwm;
static float PID_B_Bias, PID_B_Last, PID_B_Last2, PID_B_Pwm;

void PID_Reset(void)
{
	PID_A_Bias = 0; PID_A_Last = 0; PID_A_Last2 = 0; PID_A_Pwm = 0;
	PID_B_Bias = 0; PID_B_Last = 0; PID_B_Last2 = 0; PID_B_Pwm = 0;
}

float PID_A(float Encoder, float Target)
{
	PID_A_Bias = Target - Encoder;
	PID_A_Pwm += KP_SPEED * (PID_A_Bias - PID_A_Last)
	          + KI_SPEED * PID_A_Bias
	          + KD_SPEED * (PID_A_Bias - 2.0f * PID_A_Last + PID_A_Last2);
	PID_A_Last2 = PID_A_Last;
	PID_A_Last  = PID_A_Bias;
	return PID_A_Pwm;
}

float PID_B(float Encoder, float Target)
{
	PID_B_Bias = Target - Encoder;
	PID_B_Pwm += KP_SPEED * (PID_B_Bias - PID_B_Last)
	          + KI_SPEED * PID_B_Bias
	          + KD_SPEED * (PID_B_Bias - 2.0f * PID_B_Last + PID_B_Last2);
	PID_B_Last2 = PID_B_Last;
	PID_B_Last  = PID_B_Bias;
	return PID_B_Pwm;
}

/******************** 电机驱动 ********************/
void Set_Pwm(int motor_left, int motor_right)
{
	if (motor_left > 0)      { AIN11; AIN20; }
	else if (motor_left < 0) { AIN10; AIN21; }
	else                     { AIN10; AIN20; }
	set_Duty(myabs(motor_left), 0);

	if (motor_right > 0)      { BIN11; BIN20; }
	else if (motor_right < 0) { BIN10; BIN21; }
	else                      { BIN10; BIN20; }
	set_Duty(myabs(motor_right), 1);
}

void set_Duty(uint8_t duty, uint8_t channel)
{
	if (duty > 100) duty = 100;
	uint32_t cmp = 2500 - (2500 / 100) * duty;
	if (channel == 0)
		DL_Timer_setCaptureCompareValue(PWM_0_INST, cmp, DL_TIMER_CC_0_INDEX);
	else
		DL_Timer_setCaptureCompareValue(PWM_0_INST, cmp, DL_TIMER_CC_1_INDEX);
}

float PWM_Limit(float IN, float max, float min)
{
	if (IN > max) return max;
	if (IN < min) return min;
	return IN;
}

int myabs(int a)           { return (a < 0) ? -a : a; }
float myabsf(float a)      { return (a < 0.0f) ? -a : a; }

/******************** 编码器中断 ********************/
void GROUP1_IRQHandler(void)
{
	gpioA = DL_GPIO_getEnabledInterruptStatus(GPIOA, GPIO_EncoderA_PIN_0_PIN | GPIO_EncoderA_PIN_1_PIN);
	gpioB = DL_GPIO_getEnabledInterruptStatus(GPIOB, GPIO_EncoderB_PIN_2_PIN | GPIO_EncoderB_PIN_3_PIN);

	if (gpioA & GPIO_EncoderA_PIN_0_PIN) {
		if (!DL_GPIO_readPins(GPIOA, GPIO_EncoderA_PIN_1_PIN))
			gEncoderCount_left--;
		else
			gEncoderCount_left++;
	}
	else if (gpioA & GPIO_EncoderA_PIN_1_PIN) {
		if (!DL_GPIO_readPins(GPIOA, GPIO_EncoderA_PIN_0_PIN))
			gEncoderCount_left++;
		else
			gEncoderCount_left--;
	}

	if (gpioB & GPIO_EncoderB_PIN_2_PIN) {
		if (!DL_GPIO_readPins(GPIOB, GPIO_EncoderB_PIN_3_PIN))
			gEncoderCount_right--;
		else
			gEncoderCount_right++;
	}
	else if (gpioB & GPIO_EncoderB_PIN_3_PIN) {
		if (!DL_GPIO_readPins(GPIOB, GPIO_EncoderB_PIN_2_PIN))
			gEncoderCount_right++;
		else
			gEncoderCount_right--;
	}

	DL_GPIO_clearInterruptStatus(GPIOA, GPIO_EncoderA_PIN_0_PIN | GPIO_EncoderA_PIN_1_PIN);
	DL_GPIO_clearInterruptStatus(GPIOB, GPIO_EncoderB_PIN_2_PIN | GPIO_EncoderB_PIN_3_PIN);
}

/******************** 50ms定时中断 ********************/
void TIMER_Encoder_Read_INST_IRQHandler(void)
{
	switch (DL_TimerG_getPendingInterrupt(TIMER_Encoder_Read_INST)) {
	case DL_TIMER_IIDX_ZERO:
		gEncoderVal_left   = gEncoderCount_left;
		gEncoderCount_left  = 0;
		gEncoderVal_right   = gEncoderCount_right;
		gEncoderCount_right = 0;
		g_enc_dist += (gEncoderVal_left + gEncoderVal_right) / 2;
		break;
	default:
		break;
	}
}

/******************** 10ms定时中断 ********************/
void TIMER_0_INST_IRQHandler(void)
{
	switch (DL_TimerG_getPendingInterrupt(TIMER_0_INST)) {
	case DL_TIMER_IIDX_ZERO:
		break;
	default:
		break;
	}
}
