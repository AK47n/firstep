################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../OLED/OLED.c \
../OLED/OLED_DATA.c 

C_DEPS += \
./OLED/OLED.d \
./OLED/OLED_DATA.d 

OBJS += \
./OLED/OLED.o \
./OLED/OLED_DATA.o 

OBJS__QUOTED += \
"OLED\OLED.o" \
"OLED\OLED_DATA.o" 

C_DEPS__QUOTED += \
"OLED\OLED.d" \
"OLED\OLED_DATA.d" 

C_SRCS__QUOTED += \
"../OLED/OLED.c" \
"../OLED/OLED_DATA.c" 


