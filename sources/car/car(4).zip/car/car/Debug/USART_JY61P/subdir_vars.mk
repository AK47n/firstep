################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../USART_JY61P/JY61P.c \
../USART_JY61P/empty.c 

C_DEPS += \
./USART_JY61P/JY61P.d \
./USART_JY61P/empty.d 

OBJS += \
./USART_JY61P/JY61P.o \
./USART_JY61P/empty.o 

OBJS__QUOTED += \
"USART_JY61P\JY61P.o" \
"USART_JY61P\empty.o" 

C_DEPS__QUOTED += \
"USART_JY61P\JY61P.d" \
"USART_JY61P\empty.d" 

C_SRCS__QUOTED += \
"../USART_JY61P/JY61P.c" \
"../USART_JY61P/empty.c" 


