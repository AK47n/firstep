#ifndef	__CONTROL_H__
#define __CONTROL_H__

#include "ti_msp_dl_config.h"

/******************** TB6612 电机控制宏 ********************/
#define AIN11	DL_GPIO_setPins(GPIO_IN_PIN_AIN1_PORT, GPIO_IN_PIN_AIN1_PIN)
#define AIN10	DL_GPIO_clearPins(GPIO_IN_PIN_AIN1_PORT, GPIO_IN_PIN_AIN1_PIN)
#define AIN21	DL_GPIO_setPins(GPIO_IN_PIN_AIN2_PORT, GPIO_IN_PIN_AIN2_PIN)
#define AIN20	DL_GPIO_clearPins(GPIO_IN_PIN_AIN2_PORT, GPIO_IN_PIN_AIN2_PIN)

#define BIN11	DL_GPIO_setPins(GPIO_IN_PIN_BIN1_PORT, GPIO_IN_PIN_BIN1_PIN)
#define BIN10	DL_GPIO_clearPins(GPIO_IN_PIN_BIN1_PORT, GPIO_IN_PIN_BIN1_PIN)
#define BIN21	DL_GPIO_setPins(GPIO_IN_PIN_BIN2_PORT, GPIO_IN_PIN_BIN2_PIN)
#define BIN20	DL_GPIO_clearPins(GPIO_IN_PIN_BIN2_PORT, GPIO_IN_PIN_BIN2_PIN)

/************* AB模式状态机 *************/
typedef enum {
	AB_START_DELAY = 0,   // 起步：记录航向参考
	AB_RUNNING,           // 陀螺仪锁航向直行
	AB_STOPPED            // 已到达B点
} AB_State;

/************* 转弯方向 *************/
typedef enum {
	TURN_NONE = 0,
	TURN_LEFT_90,
	TURN_RIGHT_90,
	TURN_180
} TurnDir;

/************* ABCD模式状态机：交替直线盲走 & 弧线循线 *************/
typedef enum {
	CAR_FOLLOW_LINE,      // 弧线循黑线行驶
	CAR_STRAIGHT,         // 直线盲走（陀螺仪锁航向+编码器里程）
	CAR_FINISHED          // 跑完全程/停止
} Car_State;

/************* 函数声明 *************/
void Control_AB(void);
void Control_ABCDA(void);
void Control_ACBDA(void);
void Control_ACBDAx4(void);

float PID_A(float Encoder, float Target);
float PID_B(float Encoder, float Target);
void  PID_Reset(void);
void  Set_Pwm(int motor_left, int motor_right);
void  set_Duty(uint8_t duty, uint8_t channel);
float PWM_Limit(float IN, float max, float min);

int   xunji(void);
int   xunji_left(void);
int   xunji_right(void);
int   myabs(int a);
float myabsf(float a);
float gyro_straight_correction(void);

void  GYRO_Turn_Init(TurnDir dir);
int   GYRO_Turn_Process(void);    // 返回1=转弯完成
void  ABCD_State_Reset(void);
void  AB_State_Reset(void);

#endif
