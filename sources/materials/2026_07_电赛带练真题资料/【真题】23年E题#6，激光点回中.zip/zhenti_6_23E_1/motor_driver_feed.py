import serial
import time

class YunTai_Feed:
    def __init__(self) -> None:
        self.ser_5 = serial.Serial(port="/dev/ttyS5", baudrate=115200)
        self.ser_4 = serial.Serial(port="/dev/ttyS4", baudrate=115200)

    def sleep(self):
        buffer = [0xAA, 0x55, 0x01, 0x19, 0x01, 0x00, 0x00]
        buffer[-1] = self.cal_checksum(buffer)
        self.ser_4.write(bytes(buffer))
        self.ser_5.write(bytes(buffer))

    def awake(self):
        buffer = [0xAA, 0x55, 0x01, 0x19, 0x01, 0x01, 0x00]
        buffer[-1] = self.cal_checksum(buffer)
        self.ser_4.write(bytes(buffer))
        self.ser_5.write(bytes(buffer))

    def cal_checksum(self, lst):
        return sum(lst[2:-1]) & 0xFF
    
    def adjust_motor(self, motor_id, dir, angle):
        num = int(angle * 16384 / 360)
        buffer = [0xAA, 0x55, 0x01, 0x11, 0x05, dir, 0x00, 0x00, num % 256, (num // 256) % 256, 0x00]
        buffer[-1] = self.cal_checksum(buffer)
        if motor_id == "ud":
            self.ser_5.write(bytes(buffer))
        if motor_id == "lr":
            self.ser_4.write(bytes(buffer))


if __name__ == "__main__":
    yuntai = YunTai_Feed()
    yuntai.awake()

    while True:
        yuntai.adjust_motor("ud", 0, 20)
        yuntai.adjust_motor("lr", 0, 20)
        time.sleep(1)
        yuntai.adjust_motor("ud", 1, 20)
        yuntai.adjust_motor("lr", 1, 20)
        time.sleep(1)

    


