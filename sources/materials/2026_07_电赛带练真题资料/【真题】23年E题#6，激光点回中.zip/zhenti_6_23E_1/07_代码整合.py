import cv2
from xbhdcc_tools import detect_cameras, WebStreamer
import time
import numpy as np
from my_tools import convert_lab_thresholds, my_draw_rect, find_rects, find_colors

# [20, 66, 11, 127, -50, 70]

if __name__ == "__main__":
    # detect_cameras()
    # BGR
    tmp_aaaa = 0
    cap = cv2.VideoCapture(9, cv2.CAP_V4L2)

    # 设置相机数据模式
    fourcc = cv2.VideoWriter_fourcc(*'MJPG')
    cap.set(cv2.CAP_PROP_FOURCC, fourcc)

    # 设置分辨率和帧率（不能随便填，要根据实际情况）
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    cap.set(cv2.CAP_PROP_FPS, 30)

    streamer = WebStreamer(port=8081)
    fps = 0

    last_time = time.time()

    # 转换格式
    lower_color, upper_color = convert_lab_thresholds([20, 66, 11, 127, -50, 70])
    lower_rect, upper_rect = convert_lab_thresholds([44, 100, -26, 27, -24, 28])

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        frame = frame[180:540, 320:960]
        
        frame_drawn = frame.copy()
        colors, frame_drawn = find_colors(frame_drawn, lower_color, upper_color, [20, 3000])
        rects, huidu_img = find_rects(frame, lower_rect, upper_rect, [2000, 2000000])


        # aaa = 2/tmp_aaaa

        for rect in rects:
            frame = my_draw_rect(frame, rect)
        for rect in colors:
            cv2.rectangle(frame, rect[0], rect[1], (0, 255, 0), 2)

        cv2.putText(frame, "fps: {}".format(round(fps, 2)), [50, 100], cv2.FONT_HERSHEY_SIMPLEX, 3, [0, 0, 255], 4)
        streamer.update_frame(0, frame)
        streamer.update_frame(1, frame_drawn)
        curr_time = time.time()
        fps = (1 / (curr_time - last_time)) * 0.3 + fps * 0.7
        last_time = curr_time



