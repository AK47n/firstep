from motor_driver_feed import YunTai_Feed
import cv2
from xbhdcc_tools import detect_cameras, WebStreamer
import time
import numpy as np
from my_tools import convert_lab_thresholds, my_draw_rect, find_rects, find_colors, find_jiguang

if __name__ == "__main__":
    yuntai = YunTai_Feed()

    # detect_cameras()
    # BGR
    tmp_aaaa = 0
    cap = cv2.VideoCapture(9, cv2.CAP_V4L2)

    # 设置相机数据模式
    fourcc = cv2.VideoWriter_fourcc(*'MJPG')
    cap.set(cv2.CAP_PROP_FOURCC, fourcc)

    # 设置分辨率和帧率（不能随便填，要根据实际情况）
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    cap.set(cv2.CAP_PROP_FPS, 30)

    streamer = WebStreamer(port=8081)
    fps = 0

    last_time = time.time()

    # 转换格式
    

    # 胶带上
    lower_color_1, upper_color_1 = convert_lab_thresholds((0, 100, 22, 127, -128, 127))

    # 白板上的
    lower_color_2, upper_color_2 = convert_lab_thresholds((87, 100, -30, 50, -40, 31))
    

    lower_rect, upper_rect = convert_lab_thresholds((47, 100, -37, 83, -31, 37))

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        frame = frame[180:540, 320:960]
        
        frame_drawn = frame.copy()
        colors, frame_drawn = find_jiguang(frame_drawn, lower_color_1, upper_color_1, lower_color_2, upper_color_2, [2, 500])
        rects, huidu_img = find_rects(frame, lower_rect, upper_rect, [2000, 2000000])


        # aaa = 2/tmp_aaaa

        for rect in rects:
            frame = my_draw_rect(frame, rect)
        for rect in colors:
            cv2.rectangle(frame, rect[0], rect[1], (0, 255, 0), 2)

        cv2.putText(frame, "fps: {}".format(round(fps, 2)), [50, 100], cv2.FONT_HERSHEY_SIMPLEX, 3, [0, 0, 255], 4)
        streamer.update_frame(0, frame)
        streamer.update_frame(1, frame_drawn)
        curr_time = time.time()
        fps = (1 / (curr_time - last_time)) * 0.3 + fps * 0.7
        last_time = curr_time
