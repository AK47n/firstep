#include "motor.h"

float kp = 0.5; // 比例系数
float ki = 0.4; // 积分系数

int PWM_1_duty = 0;
float target_speed_1 = 0; // 目标速度 mm/s
float last_error_1 = 0;
float current_error_1 = 0;

int PWM_2_duty = 0;
float target_speed_2 = 0; // 目标速度 mm/s
float last_error_2 = 0;
float current_error_2 = 0;

extern uint32_t counter_1_A;
float speed_1 = 0;

extern uint32_t counter_2_A;
float speed_2 = 0;
extern Attitude_t current_attitude;
extern float yaw_start;

extern uint8_t task;
extern uint8_t is_start;
extern int64_t last_change_time;

void motor_init(uint8_t motor_id)
{
    DL_GPIO_setPins(DC_MOTOR_STBY_PORT, DC_MOTOR_STBY_PIN);
    if(motor_id == 1){
        // DL_Timer_startCounter(PWMAB_INST);
        DL_GPIO_setPins(DC_MOTOR_AIN1_PORT, DC_MOTOR_AIN1_PIN);
        DL_GPIO_setPins(DC_MOTOR_AIN2_PORT, DC_MOTOR_AIN2_PIN);
        DL_Timer_setCaptureCompareValue(PWMAB_INST, 0, GPIO_PWMAB_C0_IDX);
    }
    else if(motor_id == 2){
        
        DL_GPIO_setPins(DC_MOTOR_BIN1_PORT, DC_MOTOR_BIN1_PIN);
        DL_GPIO_setPins(DC_MOTOR_BIN2_PORT, DC_MOTOR_BIN2_PIN);
        DL_Timer_setCaptureCompareValue(PWMAB_INST, 0, GPIO_PWMAB_C1_IDX);
    }
    DL_Timer_startCounter(PWMAB_INST);
    DL_Timer_startCounter(MOTOR_PID_INST);
    NVIC_EnableIRQ(MOTOR_PID_INST_INT_IRQN);
}

// 限幅函数
int limit_duty(int duty)
{
    if(duty > 1300){
        duty = 1300;
    }
    if(duty < 0){
        duty = 0;
    }
    return duty;
}

void motor_set_duty(uint8_t motor_id, uint32_t duty)
{
    duty = limit_duty(duty);
    if(motor_id == 1){
        DL_Timer_setCaptureCompareValue(PWMAB_INST, duty, GPIO_PWMAB_C0_IDX);
    }
    else if(motor_id == 2){
        DL_Timer_setCaptureCompareValue(PWMAB_INST, duty, GPIO_PWMAB_C1_IDX);
    }
}

// direction: 0 停止，1 正转，2 反转
void motor_set_direction(uint8_t motor_id, uint8_t direction)
{
    if(motor_id == 1){
        if(direction == 0){
            DL_GPIO_setPins(DC_MOTOR_AIN1_PORT, DC_MOTOR_AIN1_PIN);
            DL_GPIO_setPins(DC_MOTOR_AIN2_PORT, DC_MOTOR_AIN2_PIN);
        }
        else if(direction == 1){
            DL_GPIO_setPins(DC_MOTOR_AIN1_PORT, DC_MOTOR_AIN1_PIN);
            DL_GPIO_clearPins(DC_MOTOR_AIN2_PORT, DC_MOTOR_AIN2_PIN);
        }
        else if(direction == 2){
            DL_GPIO_clearPins(DC_MOTOR_AIN1_PORT, DC_MOTOR_AIN1_PIN);
            DL_GPIO_setPins(DC_MOTOR_AIN2_PORT, DC_MOTOR_AIN2_PIN);
        }
    }
    else if(motor_id == 2){
        if(direction == 0){
            DL_GPIO_setPins(DC_MOTOR_BIN1_PORT, DC_MOTOR_BIN1_PIN);
            DL_GPIO_setPins(DC_MOTOR_BIN2_PORT, DC_MOTOR_BIN2_PIN);
        }
        else if(direction == 1){
            DL_GPIO_setPins(DC_MOTOR_BIN1_PORT, DC_MOTOR_BIN1_PIN);
            DL_GPIO_clearPins(DC_MOTOR_BIN2_PORT, DC_MOTOR_BIN2_PIN);
        }
        else if(direction == 2){
            DL_GPIO_clearPins(DC_MOTOR_BIN1_PORT, DC_MOTOR_BIN1_PIN);
            DL_GPIO_setPins(DC_MOTOR_BIN2_PORT, DC_MOTOR_BIN2_PIN);
        }
    }
}




void calculate_speed(uint8_t motor_id)
{
    if (motor_id == 1) {
        speed_1 = (float)counter_1_A / MOTOR_BIANMAQI * PI * MOTOR_WHEEL_D * 100; // 轮速 mm/s
        counter_1_A = 0; // 计算完速度后清零计数器
    }
    if (motor_id == 2) {
        speed_2 = (float)counter_2_A / MOTOR_BIANMAQI * PI * MOTOR_WHEEL_D * 100; // 轮速 mm/s
        counter_2_A = 0; // 计算完速度后清零计数器
    }
}



void DC_MOTOR_PID(uint8_t motor_id)
{
    float error;
    if (motor_id == 1) {
        error = target_speed_1 - speed_1;
        current_error_1 = error;
        PWM_1_duty += (int)(kp * (current_error_1-last_error_1) + ki *(current_error_1));
        last_error_1 = current_error_1;
        PWM_1_duty = limit_duty(PWM_1_duty);
        motor_set_duty(motor_id, PWM_1_duty);
    }
    if (motor_id == 2) {
        error = target_speed_2 - speed_2;
        current_error_2 = error;
        PWM_2_duty += (int)(kp * (current_error_2-last_error_2) + ki *(current_error_2));
        last_error_2 = current_error_2;
        PWM_2_duty = limit_duty(PWM_2_duty);
        motor_set_duty(motor_id, PWM_2_duty);
    }
}

float yaw_k_p = 9.0;
int yaw_pwm_base = 0;
float yaw_k_i = 0.03;
float yaw_total_error = 0;
extern uint8_t huidu_value[];

#define status_change_counter_init 50
int status = 0; //0陀螺仪控制车头，1是巡线状态
int status_change_times = 0; // 状态切换了多少次
int status_change_counter = status_change_counter_init; // 状态切换到陀螺仪模式倒计时


int led_beep_off_counter = 30; // 关闭声光提示倒计时
extern float last_head_for; // 上次车头朝向
extern float yaw_start_init; // 最初车头朝向

#define MAX_PWM_DIFF 400

void adjust_head()
{
    // 360 1
    float yaw_error = current_attitude.yaw - yaw_start;
    if(yaw_error > 180) yaw_error -= 360;
    else if(yaw_error < -180) yaw_error += 360;
    int pwm_diff_half = 0;
    if(yaw_error > 0.5 || yaw_error < -0.5) pwm_diff_half = (yaw_error + yaw_total_error) * yaw_k_p;
    else yaw_total_error = 0;

    if(pwm_diff_half < -MAX_PWM_DIFF) pwm_diff_half = -MAX_PWM_DIFF;
    else if(pwm_diff_half > MAX_PWM_DIFF) pwm_diff_half = MAX_PWM_DIFF;

    motor_set_duty(1, limit_duty(yaw_pwm_base - pwm_diff_half));
    motor_set_duty(2, limit_duty(yaw_pwm_base + pwm_diff_half));
    yaw_total_error += yaw_k_i * yaw_error;
}

void MOTOR_PID_INST_IRQHandler()
{
    switch (DL_Timer_getPendingInterrupt(MOTOR_PID_INST))
    {
    case DL_TIMER_IIDX_LOAD:
        if(task == 1 && is_start == 1)
        {
            yaw_pwm_base = 800;
            adjust_head();
            huidu_get_value();
            if(huidu_value[2] == 1 || huidu_value[1] == 1 || huidu_value[3] == 1)
            {
                motor_set_duty(1, 0);
                motor_set_duty(2, 0);
                is_start = 0;
                led_on();
                beep_on();
                led_beep_off_counter = 30;
            }
        }
        if(task == 2 && is_start == 1)
        {
            if(status == 0)
            {
                yaw_pwm_base = 800;
                adjust_head();
                huidu_get_value();
                if(huidu_value[2] == 1 || huidu_value[1] == 1 || huidu_value[3] == 1 || huidu_value[0] == 1 || huidu_value[4] == 1)
                {
                    if (get_time_stamp_ms() - last_change_time > 3000)
                    {
                        motor_set_duty(1, 0);
                        motor_set_duty(2, 0);
                        led_on();
                        beep_on();
                        led_beep_off_counter = 30;
                        
                        status = 1;
                        last_change_time = get_time_stamp_ms();
                        status_change_times ++;
                    }
                }
            }
            else if (status == 1)
            {
                adjust_motor_pwm();
                huidu_get_value();
                if(huidu_value[2] == 0 && huidu_value[1] == 0 && huidu_value[3] == 0 && huidu_value[0] == 0 && huidu_value[4] == 0)
                status_change_counter --;
                else status_change_counter = status_change_counter_init;
                if (status_change_counter < 0)
                {
                    if (get_time_stamp_ms() - last_change_time > 3000)
                    {
                        status = 0;
                        led_on();
                        beep_on();
                        led_beep_off_counter = 30;
                        motor_set_duty(1, 0);
                        motor_set_duty(2, 0);
                        status_change_counter = status_change_counter_init;
                        yaw_start = yaw_start + 180;
                        if(yaw_start > 360) yaw_start -= 360;
                        last_change_time = get_time_stamp_ms();
                        status_change_times ++;
                    }
                }
            }
            
            if(status_change_times == 4)
            {
                is_start = 0;
                status_change_times = 0;
                motor_set_duty(1, 0);
                motor_set_duty(2, 0);
            }
            
            
        }
        if(task == 3 && is_start == 1)
        {
            if(status == 0)
            {
                yaw_pwm_base = 800;
                adjust_head();
                huidu_get_value();
                if(huidu_value[2] == 1 || huidu_value[1] == 1 || huidu_value[3] == 1 || huidu_value[0] == 1 || huidu_value[4] == 1)
                {
                    if (get_time_stamp_ms() - last_change_time > 3000)
                    {
                        motor_set_duty(1, 0);
                        motor_set_duty(2, 0);
                        led_on();
                        beep_on();
                        led_beep_off_counter = 30;
                        
                        status = 1;
                        last_change_time = get_time_stamp_ms();
                        if (status_change_times == 0) yaw_start += 2;
                        status_change_times ++;
                    }
                }
            }
            else if (status == 1)
            {
                adjust_motor_pwm();
                huidu_get_value();
                if(huidu_value[2] == 0 && huidu_value[1] == 0 && huidu_value[3] == 0 && huidu_value[0] == 0 && huidu_value[4] == 0)
                status_change_counter --;
                else status_change_counter = status_change_counter_init;
                if (status_change_counter < 0)
                {
                    if (get_time_stamp_ms() - last_change_time > 3000)
                    {
                        status = 0;
                        led_on();
                        beep_on();
                        led_beep_off_counter = 30;
                        motor_set_duty(1, 0);
                        motor_set_duty(2, 0);
                        status_change_counter = status_change_counter_init;
                        if(status_change_times == 1) yaw_start = yaw_start + 102.8;
                        if(status_change_times == 3) yaw_start = yaw_start + 360 - 104.8;
                        if(yaw_start > 360) yaw_start -= 360;
                        last_change_time = get_time_stamp_ms();
                        status_change_times ++;
                    }
                }
            }

            
            
            if(status_change_times == 4)
            {
                is_start = 0;
                status_change_times = 0;
                motor_set_duty(1, 0);
                motor_set_duty(2, 0);
            }
            
            
        }
        if(task == 4 && is_start == 1)
        {
            if(status == 0)
            {
                yaw_pwm_base = 800;
                adjust_head();
                huidu_get_value();
                if(huidu_value[2] == 1 || huidu_value[1] == 1 || huidu_value[3] == 1 || huidu_value[0] == 1 || huidu_value[4] == 1)
                {
                    if (get_time_stamp_ms() - last_change_time > 5000)
                    {
                        motor_set_duty(1, 0);
                        motor_set_duty(2, 0);
                        led_on();
                        beep_on();
                        led_beep_off_counter = 30;
                        
                        status = 1;
                        last_change_time = get_time_stamp_ms();
                        // if (status_change_times % 4 == 0) yaw_start += 2;
                        status_change_times ++;
                    }
                }
            }
            else if (status == 1)
            {
                adjust_motor_pwm();
                huidu_get_value();
                if(huidu_value[2] == 0 && huidu_value[1] == 0 && huidu_value[3] == 0 && huidu_value[0] == 0 && huidu_value[4] == 0)
                status_change_counter --;
                else status_change_counter = status_change_counter_init;
                if (status_change_counter < 0)
                {
                    if (get_time_stamp_ms() - last_change_time > 3000)
                    {
                        status = 0;
                        led_on();
                        beep_on();
                        led_beep_off_counter = 30;
                        motor_set_duty(1, 0);
                        motor_set_duty(2, 0);
                        status_change_counter = status_change_counter_init;
                        if(status_change_times % 4 == 1) yaw_start = yaw_start_init + 102.1;
                        if(status_change_times % 4 == 3) yaw_start = yaw_start_init - 1;
                        if(yaw_start > 360) yaw_start -= 360;
                        last_change_time = get_time_stamp_ms();
                        status_change_times ++;
                    }
                }
            }
            if(status_change_times == 4 * 4)
            {
                is_start = 0;
                status_change_times = 0;
                motor_set_duty(1, 0);
                motor_set_duty(2, 0);
            }
            
            
        }
        
        led_beep_off_counter --;
        if(led_beep_off_counter < 0)
        {
            led_off();
            beep_off();
            led_beep_off_counter = 0;
        }
        // adjust_motor();
        // calculate_speed(1);
        // DC_MOTOR_PID(1);
        // calculate_speed(2);
        // DC_MOTOR_PID(2);
        break;
    // case DL_TIMER_IIDX_COMPARE_0:
    //     status = (status + 3 -1) % 3;
    //     /* code */
    //     break;
    
    default:
        break;
    }
}



