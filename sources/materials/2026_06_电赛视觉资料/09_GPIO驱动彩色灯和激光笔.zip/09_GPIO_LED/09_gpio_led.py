from periphery import GPIO
import time

# PIN 编号=X×32+Y×8+Z
# X 例如 GPIO1，则X为1
# Y 例如 GPIO1_A，则Y为0，如果是B，则Y为1，以此类推
# Z 最后一个数字，例如，这里是4
# GPIO1_A4   : 1 x 32 + 0 x 8 + 4
# GPIO1_B0 1 2  : 32 + 1 x 8 + 0   40,41,42

# 接线
# 激光笔    泰山派
#  S      GPIO1_A4
#  V         5V
#  G         GND

# 泰山派 40Pin 引脚编号速查字典
GPIO_MAP = {
    # GPIO0 组
    "GPIO0_B5": 13,
    "GPIO0_B6": 14,
    "GPIO0_B7": 15,
    
    # GPIO1 组
    "GPIO1_A4": 36,
    
    # GPIO3 组 (A组)
    "GPIO3_A1": 97,
    "GPIO3_A2": 98,
    "GPIO3_A3": 99,
    "GPIO3_A4": 100,
    "GPIO3_A5": 101,
    "GPIO3_A6": 102,
    "GPIO3_A7": 103,
    
    # GPIO3 组 (B组)
    "GPIO3_B0": 104,
    "GPIO3_B1": 105,
    "GPIO3_B2": 106,
    "GPIO3_B3": 107,
    "GPIO3_B4": 108,
    "GPIO3_B5": 109,
    "GPIO3_B6": 110,
    "GPIO3_B7": 111,
    
    # GPIO3 组 (C组)
    "GPIO3_C0": 112,
    "GPIO3_C2": 114,
    "GPIO3_C3": 115,
    "GPIO3_C4": 116,
    "GPIO3_C5": 117,
    
    # GPIO4 组
    "GPIO4_C2": 146,
    "GPIO4_C3": 147,
    "GPIO4_C5": 149,
    "GPIO4_C6": 150,
}


if __name__ == "__main__":
    JI_PIN = 36
    B_PIN = 40
    G_PIN = 41
    R_PIN = 42
    JI = GPIO(JI_PIN, "out")

    B_LED = GPIO(B_PIN, "out")
    G_LED = GPIO(G_PIN, "out")
    R_LED = GPIO(R_PIN, "out")
    while True:
        JI.write(True)
        time.sleep(1)
        JI.write(False)
        time.sleep(1)

        B_LED.write(False)
        G_LED.write(True)
        R_LED.write(True)
        time.sleep(0.5)

        B_LED.write(True)
        G_LED.write(False)
        R_LED.write(True)
        time.sleep(0.5)

        B_LED.write(True)
        G_LED.write(True)
        R_LED.write(False)
        time.sleep(0.5)

        B_LED.write(False)
        G_LED.write(False)
        R_LED.write(True)
        time.sleep(0.5)

        B_LED.write(True)
        G_LED.write(False)
        R_LED.write(False)
        time.sleep(0.5)




