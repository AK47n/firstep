import os
import subprocess
import sys
from pathlib import Path

class SystemdServiceManager:
    def __init__(self, service_name, description="My Service"):
        """
        初始化服务管理器
        
        Args:
            service_name: 服务名称（不含.service后缀）
            description: 服务描述
        """
        self.service_name = service_name
        self.description = description
        self.service_file = f"/etc/systemd/system/{service_name}.service"
        self.current_user = os.environ.get('USER', 'root')
        
    def create_service_file(self, script_path, working_dir=None, 
                           restart_policy="always", restart_sec=10,
                           run_as_user=None, dependencies="network.target"):
        """
        创建systemd服务文件
        
        Args:
            script_path: 要执行的sh脚本的完整路径
            working_dir: 工作目录（默认为脚本所在目录）
            restart_policy: 重启策略
            restart_sec: 重启等待时间
            run_as_user: 运行用户（默认当前用户）
            dependencies: 依赖的服务
        """
        if working_dir is None:
            working_dir = str(Path(script_path).parent)
            
        if run_as_user is None:
            run_as_user = self.current_user
            
        service_content = f"""# 由Python自动生成
[Unit]
Description={self.description}
After={dependencies}
Requires={dependencies}

[Service]
Type=simple
User={run_as_user}
Group={run_as_user}
WorkingDirectory={working_dir}
ExecStart=/bin/bash {script_path}
Restart={restart_policy}
RestartSec={restart_sec}
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""
        
        try:
            # 写入服务文件（需要sudo权限）
            with open(self.service_file, 'w') as f:
                f.write(service_content)
            
            # 设置正确的权限
            os.chmod(self.service_file, 0o644)
            print(f"✅ 服务文件已创建: {self.service_file}")
            return True
        except PermissionError:
            print(f"❌ 权限不足！请使用sudo运行此脚本")
            print(f"   建议: sudo python3 {sys.argv[0]}")
            return False
        except Exception as e:
            print(f"❌ 创建服务文件失败: {e}")
            return False
    
    def register_service(self):
        """注册服务到systemd"""
        try:
            # 重新加载systemd配置
            subprocess.run(['sudo', 'systemctl', 'daemon-reload'], 
                          check=True, capture_output=True)
            print("✅ Systemd配置已重新加载")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ 重新加载systemd失败: {e.stderr.decode()}")
            return False
    
    def enable_service(self):
        """启用开机自启动"""
        try:
            result = subprocess.run(
                ['sudo', 'systemctl', 'enable', f'{self.service_name}.service'],
                check=True, capture_output=True
            )
            print(f"✅ 服务 {self.service_name} 已设置为开机自启动")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ 启用服务失败: {e.stderr.decode()}")
            return False
    
    def start_service(self):
        """立即启动服务"""
        try:
            subprocess.run(['sudo', 'systemctl', 'start', f'{self.service_name}.service'],
                          check=True, capture_output=True)
            print(f"✅ 服务 {self.service_name} 已启动")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ 启动服务失败: {e.stderr.decode()}")
            return False
    
    def get_status(self):
        """获取服务状态"""
        try:
            result = subprocess.run(
                ['sudo', 'systemctl', 'status', f'{self.service_name}.service', '--no-pager'],
                capture_output=True, text=True
            )
            return result.stdout
        except Exception as e:
            return f"获取状态失败: {e}"
    
    def full_setup(self, script_path, **kwargs):
        """
        一站式完整设置
        """
        print("🚀 开始设置systemd服务...")
        print(f"📝 服务名称: {self.service_name}")
        print(f"📁 脚本路径: {script_path}")
        print("-" * 50)
        
        # 1. 检查脚本是否存在
        if not os.path.exists(script_path):
            print(f"❌ 脚本不存在: {script_path}")
            return False
            
        # 2. 确保脚本有执行权限
        os.chmod(script_path, 0o755)
        print("✅ 脚本已设置执行权限")
        
        # 3. 创建服务文件
        if not self.create_service_file(script_path, **kwargs):
            return False
            
        # 4. 注册服务
        if not self.register_service():
            return False
            
        # 5. 启用开机自启动
        if not self.enable_service():
            return False
            
        # 6. 启动服务
        if not self.start_service():
            return False
        
        print("-" * 50)
        print("🎉 服务设置完成！")
        print(f"\n📊 服务状态:")
        print(self.get_status())
        return True
    
    def remove_service(self):
        """移除服务"""
        try:
            # 停止服务
            subprocess.run(['sudo', 'systemctl', 'stop', f'{self.service_name}.service'],
                          capture_output=True)
            
            # 禁用服务
            subprocess.run(['sudo', 'systemctl', 'disable', f'{self.service_name}.service'],
                          capture_output=True)
            
            # 删除服务文件
            if os.path.exists(self.service_file):
                os.remove(self.service_file)
                print(f"✅ 服务文件已删除: {self.service_file}")
            
            # 重新加载systemd
            subprocess.run(['sudo', 'systemctl', 'daemon-reload'], check=True)
            
            print(f"✅ 服务 {self.service_name} 已完全移除")
            return True
        except Exception as e:
            print(f"❌ 移除服务失败: {e}")
            return False


def main():
    """使用示例"""
    
    # 创建服务管理器
    # 参数1: 服务名称（自定义，不要有空格）
    # 参数2: 服务描述
    manager = SystemdServiceManager(
        service_name="my-python-app",
        description="My Python Application Service"
    )
    
    # 配置参数
    script_path = "/root/my_start.sh"  # 修改为您的脚本路径
    
    # 方法1: 一键完整设置
    manager.full_setup(
        script_path=script_path,
        working_dir="/root",  # 可选
        run_as_user="root",               # 可选，默认当前用户
    )
    
    # 方法2: 分步设置（更灵活）
    """
    manager = SystemdServiceManager("my-python-app")
    
    # 创建服务文件
    manager.create_service_file("/path/to/script.sh")
    
    # 注册服务
    manager.register_service()
    
    # 启用开机启动
    manager.enable_service()
    
    # 启动服务
    manager.start_service()
    """
    
    # 查看服务状态
    print("\n" + "="*50)
    print(manager.get_status())


if __name__ == "__main__":
    # 检查是否有sudo权限
    if os.geteuid() != 0:
        print("⚠️  注意: 某些操作需要sudo权限")
        print("建议使用: sudo python3", sys.argv[0])
        print()
    
    main()