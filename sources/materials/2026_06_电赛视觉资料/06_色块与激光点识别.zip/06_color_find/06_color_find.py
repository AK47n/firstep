import cv2
from xbhdcc_tools import detect_cameras, WebStreamer
import time
import numpy as np

# [20, 66, 11, 127, -50, 70]

# 把openmv的阈值格式转成opencv需要的阈值格式
def convert_lab_thresholds(openmv_thresholds):
    l_min, l_max, a_min, a_max, b_min, b_max = openmv_thresholds
    lower_bound = np.array([int(l_min * 2.55), int(a_min + 128), int(b_min + 128)])
    upper_bound = np.array([int(l_max * 2.55), int(a_max + 128), int(b_max + 128)])
    return lower_bound, upper_bound

if __name__ == "__main__":
    # detect_cameras()
    # BGR
    cap = cv2.VideoCapture(9, cv2.CAP_V4L2)

    # 设置相机数据模式
    fourcc = cv2.VideoWriter_fourcc(*'MJPG')
    cap.set(cv2.CAP_PROP_FOURCC, fourcc)

    # 设置分辨率和帧率（不能随便填，要根据实际情况）
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    cap.set(cv2.CAP_PROP_FPS, 30)

    streamer = WebStreamer(port=8081)
    fps = 0

    last_time = time.time()

    # 转换格式
    lower_, upper_ = convert_lab_thresholds([20, 66, 11, 127, -50, 70])
    print(lower_)
    print(upper_)

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        frame = frame[180:540, 320:960]
        
        frame_drawn = frame.copy()
        # # 线段
        # cv2.line(frame_drawn, (300, 300), (500, 500), (255, 0, 255), 5)
        # # 矩形
        # cv2.rectangle(frame_drawn, (50, 100), (250, 250), (0, 255, 0), 2)
        # # 圆（实心，线宽-1就是实心）
        # cv2.circle(frame_drawn, (450, 150), 60, (255, 0, 0), -1)

        # 二值化
        frame_drawn = cv2.cvtColor(frame_drawn, cv2.COLOR_BGR2LAB)
        frame_drawn = cv2.inRange(frame_drawn, lower_, upper_)

        # 去除小噪点（变成大噪点hhhhh）
        kernel = np.ones((5, 5), np.uint8)
        frame_drawn = cv2.morphologyEx(frame_drawn, cv2.MORPH_OPEN, kernel)
        frame_drawn = cv2.morphologyEx(frame_drawn, cv2.MORPH_CLOSE, kernel)

        # # 检测边缘
        # frame_drawn = cv2.Canny(frame_drawn, 50, 150)

        # 检测多边形轮廓点，每个闭合轮廓的点放在一个cnt里面，最后组合为多维列表
        contours, _ = cv2.findContours(frame_drawn, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # 遍历每一个封闭图形
        for cnt in contours:
            # 计算面积
            area = cv2.contourArea(cnt)
            # print(area)

            # 激光点很小，这里根据实际情况调整一下
            if area < 30:
                continue
            
            # # 计算周长
            # perimeter = cv2.arcLength(cnt, True)

            # # 拟合多边形，得到顶点多维列表
            # approx = cv2.approxPolyDP(cnt, 0.02 * perimeter, True)

            # # 矩形只有四个顶点，多余的也不行
            # if not len(approx) == 4:
            #     continue

            # 获取色块的外接矩形的信息
            x, y, w, h = cv2.boundingRect(cnt)

            p0 = [x, y]
            p2 = [x + w, y + h]


            # 矩形框
            cv2.rectangle(frame, p0, p2, (0, 255, 0), 2)

            # print("approx: {}".format(approx))
        # 绘制FPS
        cv2.putText(frame, "fps: {}".format(round(fps, 2)), [50, 100], cv2.FONT_HERSHEY_SIMPLEX, 3, [0, 0, 255], 4)

        streamer.update_frame(0, frame)
        streamer.update_frame(1, frame_drawn)
        curr_time = time.time()
        fps = (1 / (curr_time - last_time)) * 0.3 + fps * 0.7
        last_time = curr_time



