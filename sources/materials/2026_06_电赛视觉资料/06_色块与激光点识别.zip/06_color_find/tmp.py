from xbhdcc_tools import detect_cameras


if __name__ == "__main__":
    detect_cameras()
    