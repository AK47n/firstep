import time
import serial

# 用UART7与电脑通信
ser = serial.Serial(port="/dev/ttyS7", baudrate=115200)

if __name__ == "__main__":
    while True:
        time.sleep(0.5)
        aaa = [0x78, 0x99]
        # ser.write(bytes(aaa))
        ser.write("xbhdcc\n".encode("utf-8"))
        ser.write("发送中文试试\n".encode("utf-8"))
        if ser.in_waiting > 0:
            data = ser.read(ser.in_waiting)
            # print(data.decode("utf-8"))
            print(list(data))
