import cv2
import numpy as np


# 把openmv的阈值格式转成opencv需要的阈值格式
def convert_lab_thresholds(openmv_thresholds):
    l_min, l_max, a_min, a_max, b_min, b_max = openmv_thresholds
    lower_bound = np.array([int(l_min * 2.55), int(a_min + 128), int(b_min + 128)])
    upper_bound = np.array([int(l_max * 2.55), int(a_max + 128), int(b_max + 128)])
    return lower_bound, upper_bound

def my_draw_rect(frame, points):
    p_0, p_1, p_2, p_3 = points
    cv2.line(frame, p_0, p_1, (0, 255, 0), 2)
    cv2.line(frame, p_1, p_2, (0, 255, 0), 2)
    cv2.line(frame, p_2, p_3, (0, 255, 0), 2)
    cv2.line(frame, p_3, p_0, (0, 255, 0), 2)
    return frame

# [2000, 20000]
def find_rects(img, lower_, upper_, area_lst, epsilon_rate=0.02):
    frame_drawn = img.copy()
    # 二值化
    frame_drawn = cv2.cvtColor(frame_drawn, cv2.COLOR_BGR2LAB)
    frame_drawn = cv2.inRange(frame_drawn, lower_, upper_)

    # 去除小噪点（变成大噪点hhhhh）
    kernel = np.ones((5, 5), np.uint8)
    frame_drawn = cv2.morphologyEx(frame_drawn, cv2.MORPH_OPEN, kernel)
    frame_drawn = cv2.morphologyEx(frame_drawn, cv2.MORPH_CLOSE, kernel)

    # 检测边缘
    frame_drawn = cv2.Canny(frame_drawn, 50, 150)

    # 检测多边形轮廓点，每个闭合轮廓的点放在一个cnt里面，最后组合为多维列表
    contours, _ = cv2.findContours(frame_drawn, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

    rects = []

    # 遍历每一个封闭图形
    for cnt in contours:
        # 计算面积
        area = cv2.contourArea(cnt)

        # 我们都矩形很大，太小的当然就不符合要求了
        if area < area_lst[0] or area > area_lst[1]:
            continue
        
        # 计算周长
        perimeter = cv2.arcLength(cnt, True)

        # 拟合多边形，得到顶点多维列表
        approx = cv2.approxPolyDP(cnt, epsilon_rate * perimeter, True)

        # 矩形只有四个顶点，多余的也不行
        if not len(approx) == 4:
            continue

        # 拿到4个顶点的坐标
        p_0 = approx[0][0] # [796,344]
        p_1 = approx[1][0] # [796,344]
        p_2 = approx[2][0] # [796,344]
        p_3 = approx[3][0] # [796,344]

        rects.append([p_0, p_1, p_2, p_3])
    
    return rects, frame_drawn


def find_colors(img, lower_, upper_, area_lst):
    frame_drawn = img.copy()
    # 二值化
    frame_drawn = cv2.cvtColor(frame_drawn, cv2.COLOR_BGR2LAB)
    frame_drawn = cv2.inRange(frame_drawn, lower_, upper_)

    # 去除小噪点（变成大噪点hhhhh）
    kernel = np.ones((5, 5), np.uint8)
    frame_drawn = cv2.morphologyEx(frame_drawn, cv2.MORPH_OPEN, kernel)
    frame_drawn = cv2.morphologyEx(frame_drawn, cv2.MORPH_CLOSE, kernel)

    # # 检测边缘
    # frame_drawn = cv2.Canny(frame_drawn, 50, 150)

    # 检测多边形轮廓点，每个闭合轮廓的点放在一个cnt里面，最后组合为多维列表
    contours, _ = cv2.findContours(frame_drawn, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    colors = []

    # 遍历每一个封闭图形
    for cnt in contours:
        # 计算面积
        area = cv2.contourArea(cnt)
        # print(area)

        # 激光点很小，这里根据实际情况调整一下
        if area < area_lst[0] or area > area_lst[1]:
            continue

        
        # # 计算周长
        # perimeter = cv2.arcLength(cnt, True)

        # # 拟合多边形，得到顶点多维列表
        # approx = cv2.approxPolyDP(cnt, 0.02 * perimeter, True)

        # # 矩形只有四个顶点，多余的也不行
        # if not len(approx) == 4:
        #     continue

        # 获取色块的外接矩形的信息
        x, y, w, h = cv2.boundingRect(cnt)

        p0 = [x, y]
        p2 = [x + w, y + h]
        colors.append([p0, p2])
    
    return colors, frame_drawn
