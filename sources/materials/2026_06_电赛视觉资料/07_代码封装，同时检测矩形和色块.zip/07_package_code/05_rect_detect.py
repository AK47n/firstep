import cv2
from xbhdcc_tools import detect_cameras, WebStreamer
import time
import numpy as np
from my_tools import convert_lab_thresholds, my_draw_rect, find_rects

# [44, 100, -26, 27, -24, 28]



if __name__ == "__main__":
    # detect_cameras()
    # BGR
    cap = cv2.VideoCapture(9, cv2.CAP_V4L2)

    # 设置相机数据模式
    fourcc = cv2.VideoWriter_fourcc(*'MJPG')
    cap.set(cv2.CAP_PROP_FOURCC, fourcc)

    # 设置分辨率和帧率（不能随便填，要根据实际情况）
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    cap.set(cv2.CAP_PROP_FPS, 30)

    streamer = WebStreamer(port=8081)
    fps = 0

    last_time = time.time()

    # 转换格式
    lower_, upper_ = convert_lab_thresholds([44, 100, -26, 27, -24, 28])
    print(lower_)
    print(upper_)

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        frame = frame[180:540, 320:960]
        
        frame_drawn = frame.copy()

        # 绘制FPS
        cv2.putText(frame, "fps: {}".format(round(fps, 2)), [50, 100], cv2.FONT_HERSHEY_SIMPLEX, 3, [0, 0, 255], 4)
        # # 线段
        # cv2.line(frame_drawn, (300, 300), (500, 500), (255, 0, 255), 5)
        # # 矩形
        # cv2.rectangle(frame_drawn, (50, 100), (250, 250), (0, 255, 0), 2)
        # # 圆（实心，线宽-1就是实心）
        # cv2.circle(frame_drawn, (450, 150), 60, (255, 0, 0), -1)

        rects, huidu_img = find_rects(frame, lower_, upper_, [2000, 2000000])
        for rect in rects:
            frame = my_draw_rect(frame, rect)

        streamer.update_frame(0, frame)
        streamer.update_frame(1, huidu_img)
        curr_time = time.time()
        fps = (1 / (curr_time - last_time)) * 0.3 + fps * 0.7
        last_time = curr_time


