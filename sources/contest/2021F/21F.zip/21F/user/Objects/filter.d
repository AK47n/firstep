.\objects\filter.o: ..\code\filter.c
.\objects\filter.o: ..\code\filter.h
.\objects\filter.o: C:\Keil5\Core\ARM\ARMCC\Bin\..\include\math.h
